import java.util.GregorianCalendar;
import java.util.LinkedList;

/**
 * TodaysRatings, a class representing the ratings from an individual day
 * @date, the day the rankings are from
 * @rankings, the rankings of the music
 * @downloads, the number of downloads of the music
 */

public class TodaysRatings {

    private GregorianCalendar date;
    private LinkedList<Integer> rankings;
    private LinkedList<Integer> downloads;

    /**
     * Constructor for TodaysRatings
     * @param date, a GregorianCalendar representing the day the rankings are from
     * @param rankings, a LinkedList representing the rankings of the music
     * @param downloads, a LinkedList representing the number of downloads of the music
     */
    public TodaysRatings(GregorianCalendar date, LinkedList<Integer> rankings, LinkedList<Integer> downloads) {
        this.date = date;
        this.rankings = rankings;
        this.downloads = downloads;
    }

    /**
     * Checks to see if the months and dates of the inputted date are the same as the parameter
     * @param month as a month input
     * @param year as a year input
     * @return true if matching dates from Gregorian calendar, false otherwise
     */
    public boolean checkDates(int month, int year) {
        if (month == this.date.get(GregorianCalendar.MONTH) && year == this.date.get(GregorianCalendar.YEAR )) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Checks to see if the month of the inputted date is different then the parameter
     * @param month as a month input
     * @return true if the month is not = to the actual month
     */
    public boolean checkDates2(int month) {
        if (month != this.date.get(GregorianCalendar.MONTH)) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Calculates the number of downloads for the songs
     * @param month as month input
     * @param year as year input
     * @return total amount of downloads
     */
    public int downloads(int month, int year) {
        int totalDownloads = 0;

        for(Integer integer : downloads) {
            totalDownloads += integer;
        }
        return totalDownloads;
    }

    /**
     * Compares the rankings of everything in the list
     * @return smallest rank within Today's Ratings
     */
    public int greatestRanking() {
        Integer small = this.rankings.get(0);
        for (Integer i : this.rankings) {
            Integer temp = i;
            if (temp < small) {
                small = temp;
            }
        }
       return small;
    }
}
