import static org.junit.Assert.*;
import org.junit.Test;
import java.util.GregorianCalendar;
import java.util.LinkedList;

public class Examples {

    public Examples() {

    }

    GregorianCalendar greg = new GregorianCalendar(2022, 11, 1);
    LinkedList<TodaysRatings> ratings = new LinkedList<TodaysRatings>();


    IRatings rate = new TodaysRatingsLL(ratings);

    RadioStation rs = new RadioStation(rate, greg);

    @Test
    public void DownloadsTest() {
        LinkedList<Integer> dl = new LinkedList<Integer>();
        dl.add(92);
        dl.add(47);
        LinkedList<Integer> rank = new LinkedList<Integer>();
        TodaysRatings tr = new TodaysRatings(greg, rank, dl);
        assertEquals(139, tr.downloads(11, 2022), 1);
    }

    @Test
    public void TotalSongDownloadsTest1() {
        assertEquals(0, rs.totalSongDownloads(11, 2022), 1);
    }

    @Test
    public void TotalSongDownloadsTest2() {
        Survey s1 = new Survey(1, 40);
        Survey s2 = new Survey(2, 30);
        LinkedList<Survey> survey = new LinkedList<Survey>();
        survey.add(s1);
        survey.add(s2);
        rs.addTodaysSurveys(survey);
        assertEquals(70, rs.totalSongDownloads(11, 2022), 1);
    }

    @Test
    public void TotalSongDownloadsTest3() {
        Survey s1 = new Survey(1, 40);
        Survey s2 = new Survey(2, 30);
        LinkedList<Survey> survey = new LinkedList<Survey>();
        survey.add(s1);
        survey.add(s2);
        rs.addTodaysSurveys(survey);
        assertEquals(0, rs.totalSongDownloads(4, 2022), 1);
    }

    @Test
    public void TotalSongDownloadsTest4() {
        Survey s1 = new Survey(1, 40);
        Survey s2 = new Survey(2, 30);
        LinkedList<Survey> survey = new LinkedList<Survey>();
        survey.add(s1);
        survey.add(s2);
        rs.addTodaysSurveys(survey);
        assertEquals(0, rs.totalSongDownloads(11, 2011), 1);
    }

    @Test
    public void TotalCheckDates() {
        LinkedList<Integer> dl = new LinkedList<Integer>();
        LinkedList<Integer> rank = new LinkedList<Integer>();

        TodaysRatings tr = new TodaysRatings(greg, rank, dl);

        assertTrue(tr.checkDates(11, 2022));
    }

    @Test
    public void TotalCheckDates2() {
        LinkedList<Integer> dl = new LinkedList<Integer>();
        LinkedList<Integer> rank = new LinkedList<Integer>();

        TodaysRatings tr = new TodaysRatings(greg, rank, dl);

        assertFalse(tr.checkDates(4, 2022));
    }

    @Test
    public void TotalCheckDates3() {
        LinkedList<Integer> dl = new LinkedList<Integer>();
        LinkedList<Integer> rank = new LinkedList<Integer>();

        TodaysRatings tr = new TodaysRatings(greg, rank, dl);

        assertFalse(tr.checkDates(11, 2011));
    }

    @Test
    public void TotalCheckDatesII() {
        LinkedList<Integer> dl = new LinkedList<Integer>();
        LinkedList<Integer> rank = new LinkedList<Integer>();
        TodaysRatings tr = new TodaysRatings(greg, rank, dl);
        assertTrue(tr.checkDates2(3));
    }

    @Test
    public void TotalCheckDatesII_2() {
        LinkedList<Integer> dl = new LinkedList<Integer>();
        LinkedList<Integer> rank = new LinkedList<Integer>();
        TodaysRatings tr = new TodaysRatings(greg, rank, dl);
        assertFalse(tr.checkDates2(11));
    }

    @Test
    public void GreatestRankingTest() {
        LinkedList<Integer> dl = new LinkedList<Integer>();
        LinkedList<Integer> rank = new LinkedList<Integer>();
        rank.add(92);
        rank.add(47);
        TodaysRatings tr = new TodaysRatings(greg, rank, dl);
        assertEquals(47, tr.greatestRanking(), 1);
    }

    @Test
    public void BestRankTest() {
        Survey s1 = new Survey(1, 40);
        Survey s2 = new Survey(2, 30);
        LinkedList<Survey> survey = new LinkedList<Survey>();
        survey.add(s1);
        survey.add(s2);
        rs.addTodaysSurveys(survey);
        assertEquals(1, rs.bestRankThisMonth(), 1);
    }

    @Test
    public void BestRankTest2() {
        Survey s1 = new Survey(5, 40);
        Survey s2 = new Survey(4, 30);
        LinkedList<Survey> survey = new LinkedList<Survey>();
        survey.add(s1);
        survey.add(s2);
        rs.addTodaysSurveys(survey);
        assertEquals(4, rs.bestRankThisMonth(), 1);
    }



    @Test
    public void BestRankTest3() {
        assertEquals(-1, rs.bestRankThisMonth(), 1);
    }















}
