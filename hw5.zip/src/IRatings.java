import java.util.LinkedList;

public interface IRatings {

    public int bestRankThisMonth(int month, int year);


    public int totalSongDownload(int month, int year);
    public void addTodaysSurveys(LinkedList<Survey> surveyList, int month, int year, int dayOfMonth);
}
