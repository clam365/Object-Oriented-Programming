/**
 * Survey, an object class representing a survey of how someone rates an instance of music
 * @Rank, the numerical ranking of the survey
 * @Downloads, the number of times a song has been downloaded
 */

public class Survey {
    private int rank;
    private int downloads;

    /**
     * Constructor for Survey
     * @param rank, an int greater than 1 representing the numerical ranking of a survey
     * @param downloads,an int greater than 0 representing the number of downloads for a survey
     */

    public Survey(int rank, int downloads) {
        this.rank = rank;
        this.downloads = downloads;
    }

    /**
     * Getter for rank
     * @return rank (int)
     */
    public int getRank() {
        return this.rank;
    }

    /**
     * Getter for downloads
     * @return downloads (int)
     */
    public int getDownloads() {
        return this.downloads;
    }
}
