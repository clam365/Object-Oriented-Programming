import java.util.GregorianCalendar;
import java.util.LinkedList;


public class TodaysRatingsLL implements IRatings {

    private LinkedList<TodaysRatings> ratingsLL = new LinkedList<TodaysRatings>();

    /**
     * Constructor for TodaysRatingsLL
     * @param ratingsLL, a LinkedList of TodaysRatings representing the list of ratings present
     */
    public TodaysRatingsLL(LinkedList<TodaysRatings> ratingsLL) {
        this.ratingsLL = ratingsLL;
    }

    /**
     * bestRankThisMonth(int month, int year)
     * @param month, the month that the rankings are from
     * @param year, the year that the rankings are from
     * @return smallest, the best (the least numerical value) ranking from a given month
     */

    public int bestRankThisMonth(int month, int year) {
        if (ratingsLL.size() == 0) {
            return -1;
        }
        int smallest = this.ratingsLL.get(0).greatestRanking();
        //Checks whether there is any data for this month

            // Iterating through List of Today's Ratings
            for (TodaysRatings t : ratingsLL) {
                //Conditional checking matching days
                if (t.checkDates(month, year) == true) {
                    int temp = t.greatestRanking();
                    if (smallest > temp) {
                        smallest = temp;
                    }
                }
            }

        return smallest;
    }








    /**
     * Calculates the total song downloads
     * @param month, the month that the downloads are from
     * @param year, the year that the downloads are from
     * @return totalDownloads, the total number of music downloads
     */

    public int totalSongDownload(int month, int year) {
        int totalSum = 0;
        for(TodaysRatings t : ratingsLL) {
            if (t.checkDates(month, year) == true) {
                totalSum += t.downloads(month, year);
            }
        }
       return totalSum;
    }

    /**
     * Adds a survey to the list
     * @param surveyList, a linked list of the music surveys present
     */

    public void addTodaysSurveys(LinkedList<Survey> surveyList, int month, int year, int dayOfMonth) {
        GregorianCalendar resultPortion1 = new GregorianCalendar(year, month, dayOfMonth +1);
        LinkedList<Integer> resultPortion2 = new LinkedList<Integer>();
        LinkedList<Integer> resultPortion3 = new LinkedList<Integer>();

        for (Survey s : surveyList) {
            resultPortion2.add(s.getRank());
            resultPortion3.add(s.getDownloads());
        }
        TodaysRatings result = new TodaysRatings(resultPortion1,resultPortion2, resultPortion3);
        ratingsLL.add(result);
    }

}
