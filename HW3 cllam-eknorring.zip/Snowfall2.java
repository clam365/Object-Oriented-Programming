import com.jayway.jsonpath.internal.function.numeric.Max;
import io.perfmark.Link;

import java.util.LinkedList;

class Snowfall2 {
  Snowfall2(){}

  // checks whether a datum is a date
  boolean isDate(double anum) { return (int)anum >= 101; } // Jan 1st
  // extracts the month from an 4-digit date
  int extractMonth(double dateNum) { return ((int)( dateNum / 100)); }


  public LinkedList<Double> cleanTheData(LinkedList<Double> dataToClean, int month) {
    LinkedList<Double> cleanedData = new LinkedList<Double>();

    for (int i = 0; i < dataToClean.size(); i++) {
      if(month == this.extractMonth(dataToClean.get(i))) {
        cleanedData.add(dataToClean.get(i));

        for (int j = i + 1; j < dataToClean.size(); j++) {
          if (dataToClean.get(j) > 99 && this.extractMonth(dataToClean.get(j)) > month) {
            return cleanedData;
          }
          else if (dataToClean.get(j) > 0){
            cleanedData.add(dataToClean.get(j));
          }
        }
      }
    }
    return cleanedData;
  }

  public LinkedList<MaxInchReport> dailyMaxForMonth(LinkedList<Double> data, int month) {
    double date = 0.0;
    double maxInches = 0.0;

    MaxInchReport temp = new MaxInchReport(date, maxInches);
    LinkedList<MaxInchReport> endResult =  new LinkedList<MaxInchReport>();

    // This is the filtered data through the method cleanTheData
    LinkedList<Double> cleanData = this.cleanTheData(data, month);

    LinkedList<Double> maxComparison = new LinkedList<Double>();

    for (int i = 0; i < cleanData.size(); i++) {
      if(month == this.extractMonth(cleanData.get(i))) {
        date = cleanData.get(i);
        LinkedList<Double> tempDouble = new LinkedList<Double>();
        for(int j = i + 1 ; j < cleanData.size(); j++) {


          if (cleanData.get(j) > 99 )  {
            tempDouble = tempDouble;
          }
          else if (cleanData.get(j) > 0){
            tempDouble.add(cleanData.get(j));
          }

          Double maxDouble = 0.0;
          for (Double d : tempDouble) {
            if (d > maxDouble) {
              maxDouble = d;
            }
          }
          maxInches = maxDouble;
        }
        endResult.add(new MaxInchReport(date, maxInches));
      }
    }
    return endResult;
  }

}