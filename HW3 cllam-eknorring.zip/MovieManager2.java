import java.util.LinkedList;

class MovieManager2 {
	
	MovieManager2() {}

	public Programme organizeMovies(LinkedList<Movie> movies)
	{
		LinkedList<Movie> filtered = new LinkedList<Movie>();
		for (int i = 0; i < movies.size(); i++) {
			if (movies.get(i).simulcast == false) {
				filtered.add(movies.get(i));
			}
		}
		Programme programmeOutput = new Programme();
		for (Movie m: filtered) {
			if (m.showtime >= 700 && m.showtime < 1200) {
				programmeOutput.matinee.add(m);
			}
			else if (m.showtime >= 1200 && m.showtime < 2000) {
				programmeOutput.primetime.add(m);
			}
			else {
				programmeOutput.soiree.add(m);
			}
		}
		return programmeOutput;
	}


}
	

