import java.util.LinkedList;

class MovieManager1 {
	
	MovieManager1() {}



	public LinkedList<Movie> cleanTheData(LinkedList<Movie> dataToClean) {
		LinkedList<Movie> cleanedData = new LinkedList<Movie>();

		for (Movie m: dataToClean) {
			if (m.simulcast == false) {
				cleanedData.add(m);
			}
		}
		return cleanedData;
	}

	public Programme organizeMovies(LinkedList<Movie> movies)
	{
		Programme programmeOutput = new Programme();
		LinkedList<Movie> cleanedData = this.cleanTheData(movies);

		for (Movie m : cleanedData) {
			if (m.showtime >= 700 && m.showtime < 1200) {
				programmeOutput.matinee.add(m);
			}
			else if (m.showtime >= 1200 && m.showtime < 2000) {
				programmeOutput.primetime.add(m);
			}
			else {
				programmeOutput.soiree.add(m);
			}
		}
		return programmeOutput;
	}
	
}
