import org.junit.Test;

import java.util.LinkedList;

class Programme {
	
	LinkedList<Movie> matinee;
	LinkedList<Movie> primetime;
	LinkedList<Movie> soiree;
	
	Programme()
	{
		this.matinee = new LinkedList<Movie>();
		this.primetime = new LinkedList<Movie>();
		this.soiree = new LinkedList<Movie>();
	}
	
	Programme(LinkedList<Movie> matinee, LinkedList<Movie> primetime, LinkedList<Movie> soiree)
	{
		this.matinee = matinee;
		this.primetime = primetime;
		this.soiree = soiree;
	}


	public boolean equals(Object obj) {

		Programme programme1 = (Programme) obj;

		if ( (this.matinee.size() != programme1.matinee.size()) || (this.primetime.size() != programme1.primetime.size()) || (this.soiree.size() != programme1.soiree.size())) {
			return false;
		}
		else {
			//reviewing matinee
			for (int i = 0; i < this.matinee.size(); i++) {
				//title comparison
				if ( !(this.matinee.get(i).title.equals(programme1.matinee.get(i).title)) ) {
					return false;
				}
				//showtime comparison
				else if ( this.matinee.get(i).showtime != programme1.matinee.get(i).showtime ) {
					return false;
				}

			}
			//Primetime Iteration
			for (int i = 0; i < this.primetime.size(); i++) {
				//title comparison
				if ( !(this.primetime.get(i).title.equals(programme1.primetime.get(i).title)) ) {
					return false;
				}
				//showtime comparison
				else if ( this.primetime.get(i).showtime != programme1.primetime.get(i).showtime ) {
					return false;
				}

			}
			//Soiree Iteration
			for (int i = 0; i < this.soiree.size(); i++) {
				//title comparison
				if ( !(this.soiree.get(i).title.equals(programme1.soiree.get(i).title)) ) {
					return false;
				}
				//showtime comparison
				else if ( this.soiree.get(i).showtime != programme1.soiree.get(i).showtime ) {
					return false;
				}
				//runtime comparison

			}

			return true;
		}
	}


}
