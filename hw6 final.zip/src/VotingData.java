// Imports
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;

public class VotingData {

    // Fields
    private LinkedList<String> ballot = new LinkedList<String>();
    private LinkedList<String> votes = new LinkedList<String>();
    Scanner keyboard = new Scanner(System.in);

    // Hashmaps
    private HashMap<String, Integer> firstVotesMap = new HashMap<>();
    private HashMap<String, Integer> secondVotesMap = new HashMap<>();
    private HashMap<String, Integer> thirdVotesMap = new HashMap<>();

    /**
     * Getter
     * @return linkedlist of ballet
     */
    public LinkedList<String> getBallot() {
        return this.ballot;
    }

    /**
     * The method submitVote takes three strings and returns void. It stores a single voter's choice in the data structure.
     * @param firstChoice is a new string.
     * @param secondChoice is a new string.
     * @param thirdChoice is a new string.
     * @throws CandidateChosenMoreThanOnceException if there are multiple candidates in the hashmap, then a new exception is thrown.
     * @throws CandidateNotFoundException if there is no candidate in the hashmap, a new exception is thrown.
     */
    public void submitVote(String firstChoice, String secondChoice, String thirdChoice) throws CandidateNotFoundException, CandidateChosenMoreThanOnceException {

        if (firstChoice.equals(secondChoice) || firstChoice.equals(thirdChoice)) {
            throw new CandidateChosenMoreThanOnceException(firstChoice);
        }
        else if (secondChoice.equals(thirdChoice)) {
            throw new CandidateChosenMoreThanOnceException(secondChoice);
        }

        if(!ballot.contains(firstChoice)) {
            throw new CandidateNotFoundException(firstChoice);
        }
        else if(!ballot.contains(secondChoice)) {
            throw new CandidateNotFoundException(secondChoice);
        }
        else if(!ballot.contains(thirdChoice)) {
            throw new CandidateNotFoundException(thirdChoice);
        }

        firstVotesMap.put(firstChoice, firstVotesMap.get(firstChoice) + 1);
        secondVotesMap.put(secondChoice, secondVotesMap.get(secondChoice) + 1);
        thirdVotesMap.put(thirdChoice, thirdVotesMap.get(thirdChoice) + 1);
    }

    /**
     * A method that takes one string and adds the candidate to the ballot, returning void.
     * @param candidate is a new string.
     * @throws RedundantCandidateException if the named candidate was already on the ballot.
     */
    public void nominateCandidate(String candidate) throws RedundantCandidateException {
        if (ballot.contains(candidate)) throw new RedundantCandidateException(candidate);
        ballot.add(candidate);
        firstVotesMap.put(candidate, 0);
        secondVotesMap.put(candidate, 0);
        thirdVotesMap.put(candidate, 0);
    }

    /**
     * The method finds the winner which a candidate with more than 50% of first place votes.
     * @return the winner (candidate).
     */
    public String pickWinnerMostFirstChoice() {
        float votes = 0;
        for (Map.Entry<String, Integer> candidate : firstVotesMap.entrySet()) {
            votes = votes + candidate.getValue();
        }
        for (Map.Entry<String, Integer> candidate : firstVotesMap.entrySet()) {
            if (candidate.getValue() > votes/2) {
                return candidate.getKey();
            }
        }
        return "*Requires Runoff Poll*";
    }


    /**
     * A method that takes the winner which is the candidate with the most points calculated from the highest amount of votes from any tier.
     * @return the winner (candidate).
     */
    public String pickWinnerMostAgreeable() {
        HashMap<String, Integer> biggest =  new HashMap<>();

        for (String s: firstVotesMap.keySet()) {
            Integer maxValue = 0;
           if (firstVotesMap.get(s) > secondVotesMap.get(s) && firstVotesMap.get(s) > thirdVotesMap.get(s)) {
               maxValue = firstVotesMap.get(s);
            } else if (secondVotesMap.get(s) > thirdVotesMap.get(s)) {
               maxValue = secondVotesMap.get(s);
            } else {
               maxValue = thirdVotesMap.get(s);
            }

           biggest.put(s, maxValue);
        }

        // Find max value out of all candidates
        String max = "";
        Integer mav = Integer.MIN_VALUE;

        for (String s: biggest.keySet()) {
            if ( biggest.get(s) > mav) {
                mav = biggest.get(s);
                max = s;
            }

        }
        return max;
    }
}