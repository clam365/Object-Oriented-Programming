import java.util.Scanner;

public class PollingDevice {
    VotingData election = new VotingData();


    public PollingDevice(VotingData election) {
        this.election = election;
    }

    public void printBallot() {
        System.out.println("The candidates are ");
        for (String s : election.getBallot()) {
            System.out.println(s);
        }
    }

    /**
     *
     * @throws RedundantCandidateException when a candidate that is already on the ballot is added
     */

    public void screen() throws RedundantCandidateException {
        this.printBallot();
        System.out.println("Who is your first choice?");
        String candidate1 = election.keyboard.next();
        System.out.println("Who is your second choice?");
        String candidate2 = election.keyboard.next();
        System.out.println("Who is your third choice?");
        String candidate3 = election.keyboard.next();
        System.out.println("You voted for " + candidate1 + "," + candidate2 + ", and" + candidate3);

        try {
            election.submitVote(candidate1, candidate2, candidate3);
        }
        catch (CandidateChosenMoreThanOnceException e) {
            System.out.println("You need to vote for 3 unique candidates");
            screen();
        }
        catch (CandidateNotFoundException e) {
            System.out.println("You have to vote for candidates on the ballot");
            System.out.println("Would you like to vote for a write in candidate? Press Y to proceed.");
            String yn = election.keyboard.next();
            if (yn.equals("Y")) {
                System.out.println("Enter a name");
                String c = election.keyboard.next();
                addWriteIn(c);
            }
            screen();
        }
        System.out.println("You voted for " + candidate1 + "," + candidate2 + ", and" +candidate3);
    }

    /**
     * write your own candidate to vote for
     * @param c: candidate to be added into election
     */
    public void addWriteIn(String c) throws RedundantCandidateException {
        /**
        try {
            election.nominateCandidate(c);
        }
        catch (RedundantCandidateException e) {
            System.out.println("Candidate exists already.");
        }
         **/

        if (election.getBallot().contains(c)) {
            System.out.println("Candidate exists already.");
            throw new RedundantCandidateException(c);
        }
        else {
            election.nominateCandidate(c);
            System.out.println("Candidate added.");
        }
    }


}