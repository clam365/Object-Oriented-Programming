import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class Examples {





    // method to set up a ballot and cast votes

    VotingData setup1() {


        VotingData vd = new VotingData();

        // put candidates on the ballot
        try {

            vd.nominateCandidate("gompei");
            vd.nominateCandidate("husky");
            vd.nominateCandidate("ziggy");

        } catch (Exception e) {}

        // cast votes

        try {

            vd.submitVote("gompei", "husky", "ziggy");
            vd.submitVote("gompei", "ziggy", "husky");
            vd.submitVote("husky", "gompei", "ziggy");

        } catch (Exception e) {}

        return(vd);


    }

    VotingData setup2() {

        VotingData vd = new VotingData();

        // put candidates on the ballot
        try {

            vd.nominateCandidate("Bob");
            vd.nominateCandidate("Alice");
            vd.nominateCandidate("Fernando Tatis Jr");

        } catch (Exception e) {}

        // cast votes

        try {

            vd.submitVote("Bob", "Alice", "Fernando Tatis Jr");
            vd.submitVote("Alice", "Fernando Tatis Jr", "Bob");
            vd.submitVote("Fernando Tatis Jr", "Bob", "Alice");

        } catch (Exception e) {}

        return(vd);

    }

    VotingData setup3() {

        VotingData vd = new VotingData();

        // put candidates on the ballot
        try {

            vd.nominateCandidate("Fernando Tatis Jr");
            vd.nominateCandidate("Fernando Tatis Jr");
            vd.nominateCandidate("Fernando Tatis Jr");

        } catch (Exception e) {}

        // cast votes

        try {

            vd.submitVote("Fernando Tatis Jr", "Fernando Tatis Jr", "Fernando Tatis Jr");
            vd.submitVote("Fernando Tatis Jr", "Fernando Tatis Jr", "Fernando Tatis Jr");
            vd.submitVote("Fernando Tatis Jr", "Fernando Tatis Jr", "Fernando Tatis Jr");

        } catch (Exception e) {}

        return(vd);

    }

    // now run a test on a specific election


    @Test
    public void testMostFirstWinnerNoRunoff () {
        assertEquals("gompei", this.setup1().pickWinnerMostFirstChoice());
    }

    @Test
    public void testMostFirstWinnerRunoff () {
        assertEquals("*Requires Runoff Poll*", this.setup2().pickWinnerMostFirstChoice());
    }

    @Test
    public void testMostAgreeableWinner() {
        assertEquals("ziggy", this.setup1().pickWinnerMostAgreeable());
    }

    @Test
    public void testMostAgreeableWinnerRunoff() {
        assertEquals("*Requires Runoff Poll*", this.setup2().pickWinnerMostFirstChoice());
    }

    @Test(expected=CandidateChosenMoreThanOnceException.class)
    public void testCandidateChosenMoreThanOnceException() throws CandidateChosenMoreThanOnceException
    {
        try {
            setup3().submitVote("Fernando Tatis Jr", "Fernando Tatis Jr", "Fernando Tatis Jr");
        }
        catch (CandidateNotFoundException e){

    }
    }

    @Test(expected=CandidateNotFoundException.class)
    public void testCandidateNotFoundException() throws CandidateNotFoundException
    {
        try {
            setup3().submitVote("Alice", "Yusuf", "Bob");
        }
        catch (CandidateChosenMoreThanOnceException e){

        }
    }


    @Test(expected=RedundantCandidateException.class)
    public void testRedundantException() throws RedundantCandidateException
    {
        VotingData vd = new VotingData();
        vd.nominateCandidate("The Killer Klowns From Outer Space");


        PollingDevice pd = new PollingDevice(vd);
        pd.addWriteIn("The Killer Klowns From Outer Space");
    }






}
