import java.util.LinkedList;

public class LitJam {
    int genres;
    LinkedList<Literarian> lol = new LinkedList<Literarian>();

    public LitJam(int genres, LinkedList lol) {
        this.genres = genres;
        this.lol = lol;
    }

    /**
     * Creates a list of readers who did not finish the challenge
     * @return a list of readers
     */
    public LinkedList readingDNF() {
        LinkedList<String> literaryList = new LinkedList<String>();
        for (Literarian l : lol) {
            if (((l.newcr.readresult.log.get(0).booksread) + (l.newcr.readresult.log.get(1).booksread)) < genres) {
                literaryList.add(l.penName);
            }
        }
        return literaryList;
    }

    /**
     * Calculates a literarian's final score for the challenge based on how well they did overall
     * @param literaryName, the literarian's pen name
     * @return a numerical value score
     */
    public int finalScoreForLiterarian(String literaryName) {
        int points = 0;
        //LinkedList<String> literaryList = new LinkedList<String>();

        for (Literarian l : lol) {
            //Iterating through list for the Literarian
            if (l.penName.equals(literaryName)) {
                if (((l.newcr.readresult.log.get(0).booksread) + (l.newcr.readresult.log.get(1).booksread)) >= genres)
                {
                    points += 25;
                }
                for (BooksRead r : l.newcr.readresult.log) {
                    if (r.skimmed == false) {
                        points = (int) points + 5;
                    }
                }
                if (l.newcr.readresult.average > l.newcr.readresult.averagePerDay()) {
                    points += 5;
                }

                double count = 0;
                for (double w : l.newcr.writeresult.words) {
                    w += w + l.newcr.writeresult.words.element();
                    count = w;
                }
                if (count > 50000) {
                    points += 25;
                    points = points + (5 * (30 - l.newcr.writeresult.day));
                }
            }
        }
        return points;
    }

    /**
     * Determines whether any of the literarians in "this" LitJam object
     * had a higher final score than they did in the parameter LitJam.
     * @param litjam, the comparison litjam that "this" LitJam is going up against
     * @return true if there was improvement, or false if there was not
     */
    public boolean anyImprovement(LitJam litjam) {
        for (Literarian l : lol) {
            String name = l.penName;

            if (this.finalScoreForLiterarian(name) > litjam.finalScoreForLiterarian(name)) {
                return true;
            }
        }
        return false;
    }

    /*
    13. For our final methods, we did include helper functions which definitely made it easier to keep track of
    everything. Overall, we're pretty satisfied with how things went, although we did do anyImprovement wrong the first
    time because we ended up overthinking and overcomplicating it so with hindsight we would be able to streamline how
    we did that one. There's always opportunity to add more helper functions as well, though in this case they didn't
    seem strictly necessary.
     */





}
