import java.util.LinkedList;

public class PoemResult extends AbsResult implements IChallenge {
    int weeks;

    public PoemResult(double words2, int day, int weeks) {
        super(words2, day);
        this.weeks = weeks;
    }

    /**
     * Adds the number of words to the linked list of number of words written and
     * increases the int field describing how many weeks have had a submitted poem by one if the boolean parameter is true.
     * @param word, the number of words written
     * @param newPoem, indicating if a new poem was submitted
     * @return true or false
     */

    public PoemResult nextPoem(double word, boolean newPoem) {
        words.add(word);
        if (newPoem) {
            weeks += 1;
        }
        return this;
    }

    /**
     * Calculates the average number of words written per day
     * @return the average
     */

    public double averagePerDay() {
        double total = 0;
        for(Double thisChapter: this.words) {
            total += words.element() ;
        }
        return total/day;
    }

    /**
     * Represents how far away a literarian's average is from their goal
     * @return how many more words are needed to reach the goal
     */

    public double differenceFromGoal() {
        if (weeks == 0) {
            return ((this.averagePerDay() * (4-weeks)) / (31 - day + 1));
        }
        else {
            return (((this.averagePerDay() / weeks ) * (4-weeks)) / (31 - day + 1));
        }
    }



}
