public class ChallengeResult {
    ReadingResult readresult;
    WritingResult writeresult;

    public ChallengeResult(ReadingResult readresult, WritingResult writeresult) {
        this.readresult = readresult;
        this.writeresult = writeresult;
    }

    public double howClose() {
        return ((readresult.differenceFromGoal() * 10000) + writeresult.differenceFromGoal());
    }
}
