import static org.junit.Assert.*;
import org.junit.Test;
import java.util.LinkedList;

public class Examples {

    public Examples() {

    }

    BooksRead booksRead1 = new BooksRead(1.0, "fiction",false);
    BooksRead booksRead2 = new BooksRead(3.5, "non-fiction", true);
    BooksRead booksRead3 = new BooksRead(1.0, "fiction",false);
    BooksRead booksRead4 = new BooksRead(4.0, "mystery", false);
    BooksRead booksRead5 = new BooksRead(300.0, "yusuf genre", false);
    BooksRead booksRead6 = new BooksRead(12.0, "adventure", false);
    BooksRead booksRead7 = new BooksRead(24.0, "action", true);

    BooksRead booksRead8 = new BooksRead(0, "no", true);
    BooksRead booksRead9 = new BooksRead(0, "no", true);


    // test making each of the Result classes
    ReadingResult readingResult = new ReadingResult(2, booksRead1, booksRead2);
    //goal average books per day, fiction books read, non fiction books read.
    ReadingResult readingResult2 = new ReadingResult(3, booksRead1, booksRead3);
    ReadingResult readingResult3 = new ReadingResult(3, booksRead4, booksRead5);
    ReadingResult readingResult4 = new ReadingResult(3, booksRead6, booksRead7);

    ReadingResult readingResult5 = new ReadingResult(2, booksRead8, booksRead9);

    WritingResult writingResult = new WritingResult(2500.5, 15);
    WritingResult writingResult2 = new WritingResult(0, 0);
    WritingResult writingResult3 = new WritingResult(900000000, 7);


    //words written, last day novel was updated
    ChallengeResult challengeResult = new ChallengeResult(readingResult,
            writingResult);
    ChallengeResult challengeResult2 = new ChallengeResult(readingResult5, writingResult2);

    ChallengeResult challengeResult3 = new ChallengeResult(readingResult3, writingResult3);
    // test making literarians
    Literarian literarian1 = new Literarian("Litty", challengeResult);
    Literarian literarian2 = new Literarian("Reeds", challengeResult);
    Literarian literarian3 = new Literarian("Terrible Reader", challengeResult2);
    Literarian literarian4 = new Literarian("Excellent Reader", challengeResult3);

    BooksRead techManuals = new BooksRead(100, "technical manuals", false);

    PoemResult poemResult = new PoemResult(100,5,1);



//--------------------------------------------------------------------

    @Test
     //checks if chapter is added to linked-list
    public void  testWritingResultNextChapter() {
        assertEquals(writingResult.nextChapter(200), writingResult);
    }

    @Test
    public void testWritingResultAveragePerDay() {
        LinkedList<Double> test1 = new LinkedList<Double>();
        test1.add(2500.5);
        assertEquals(test1.element()/15, 166.7, 0.01);
    }

    @Test
    public void testWritingResultAveragePerDay1() {
        assertEquals(writingResult.averagePerDay(), 166.7, 0.01);
    }

    @Test
    public void testReadingResultAveragePerDay() {
        assertEquals(readingResult.averagePerDay(), 4.5, 0.01);
    }

    @Test
    public void testPoemResultAveragePerDay() {
        assertEquals(poemResult.averagePerDay(), 20.0, 0.1);
    }

    @Test
    public void testWritingResultDifferenceFromGoal() {
        assertEquals(writingResult.differenceFromGoal(), 156.28, 0.01);
    }

    @Test
    public void testReadingResultDifferenceFromGoal() {
        assertEquals(readingResult.differenceFromGoal(), -2.5, 0.01);
    }

    @Test
    public void testPoemResultDifferenceFromGoal() {
        assertEquals(poemResult.differenceFromGoal(), 2.22, 0.01);
    }

    @Test
    public void testNextPoem() {
        assertEquals(poemResult.nextPoem(200, false), poemResult);
    }

    @Test
    public void testBestGenreByType() {
        assertEquals(readingResult2.bestGenreByType(false), "fiction");
    }

    @Test
    public void testBestGenreByTypeMadeUpGenre() {
        assertEquals(readingResult3.bestGenreByType(false), "yusuf genre");
    }

    @Test
    public void testBestGenreByTypeInvestedOnly() {
        assertEquals(readingResult4.bestGenreByType(true), "adventure");
    }

    @Test
    public void testReadingDNF() {

        LinkedList<Literarian> lol = new LinkedList<Literarian>();
        lol.add(literarian1);
        lol.add(literarian3);
        lol.add(literarian4);
        LinkedList<String> result = new LinkedList<String>();
        result.add(literarian1.penName);
        result.add(literarian3.penName);
        LitJam l1 = new LitJam(5, lol);

        assertEquals(l1.readingDNF(), result);

    }

    @Test
    public void testReadingDNFEmpty() {

        LinkedList<Literarian> lol = new LinkedList<Literarian>();
        lol.add(literarian4);
        LinkedList<String> result = new LinkedList<String>();
        LitJam l1 = new LitJam(5, lol);

        assertEquals(l1.readingDNF(), result);

    }

@Test
    public void testFinalScore() {
        LinkedList<Literarian> lol = new LinkedList<Literarian>();
        lol.add(literarian1);
        lol.add(literarian3);
        lol.add(literarian4);
        LitJam l1 = new LitJam(2, lol);
        assertEquals(l1.finalScoreForLiterarian("Litty"), 30, .1);
    }

    @Test
    public void testFinalScore2() {
        LinkedList<Literarian> lol = new LinkedList<Literarian>();
        lol.add(literarian1);
        lol.add(literarian3);
        lol.add(literarian4);
        LitJam l1 = new LitJam(2, lol);
        assertEquals(l1.finalScoreForLiterarian("Excellent Reader"), 175, .1);
    }

    @Test
    public void testFinalScore3() {
        LinkedList<Literarian> lol = new LinkedList<Literarian>();
        lol.add(literarian1);
        lol.add(literarian3);
        lol.add(literarian4);
        LitJam l1 = new LitJam(2, lol);
        assertEquals(l1.finalScoreForLiterarian("Terrible Reader"), 5, .1);
    }



    @Test
    public void testAnyImprovementTrue() {
        LinkedList<Literarian> lol = new LinkedList<Literarian>();
        lol.add(literarian1);
        lol.add(literarian3);
        lol.add(literarian4);
        LitJam l1 = new LitJam(2, lol);
        LitJam l2 = new LitJam(5, lol);
        assertTrue(l1.anyImprovement(l2));
    }

    @Test
    public void testAnyImprovementFalse() {
        LinkedList<Literarian> lol = new LinkedList<Literarian>();
        lol.add(literarian1);
        lol.add(literarian3);
        lol.add(literarian4);
        LitJam l1 = new LitJam(2, lol);
        LitJam l2 = new LitJam(5, lol);
        assertFalse(l2.anyImprovement(l1));
    }





















}

