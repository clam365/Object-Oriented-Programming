import java.util.LinkedList;

public class AbsResult {
    LinkedList<Double> words = new LinkedList<Double>();
    int day;

    public AbsResult(double word, int day) {
        words.add(word);
        this.day = day;
    }
}
