import java.awt.print.Book;
import java.util.LinkedList;
import java.util.Collection;

public class ReadingResult implements IChallenge {

    // Average books per-day goal set in advanced
    int average;

    //list of genres
    LinkedList<BooksRead> log = new LinkedList<BooksRead>();


    //Constructor
    public ReadingResult(int average, BooksRead fiction, BooksRead nonfiction) {
        this.average = average;
        log.add(fiction);
        log.add(nonfiction);
    }

    /**
     * Adds a book to a list of books
     * @param random, a given book to be added
     * @return the new list with the addiiton in place
     */

    public ReadingResult readSomeBooks(BooksRead random) {
        log.add(random);
        return this;
    }

    /**
     * Finds the most common genre in a list of books with relation to if they were invested readers or not
     * @param invested, whether the reader skimmed
     * @return the most common genre as a String
     */

    public String bestGenreByType(boolean invested) {
        if (invested == true) {
            int max = 0;
            String best = "";
            for (BooksRead book : log) {
                if (book.skimmed == false) {
                    if (book.booksread > max) {
                        max = (int) book.booksread;
                        best = book.genre;
                    }
                }
                return best;
            }

        } else {
            int max = 0;

            BooksRead current = new BooksRead(1.0, "", false);
            String best = "";
            for (BooksRead book : this.log) {
                if (book.booksread > max) {
                    max = (int) book.booksread;
                    best = book.genre;
                }
            }
            return best;
        }
        return null;
    }

    public double averagePerDay() {
        double count = 0;
        for(BooksRead book: this.log) {
            count += book.booksread;
        }
        return count;
    }

    public double differenceFromGoal() {
        return (average - this.averagePerDay());
    }





}
