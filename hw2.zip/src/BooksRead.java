public class BooksRead {

    // books read (includes partial)
    double booksread;

    //genre of book
    String genre;

    //true if reading was skimmed, false if invested
    boolean skimmed;

    public BooksRead(double booksread, String genre, boolean skimmed) {
        this.booksread = booksread;
        this.genre = genre;
        this.skimmed = skimmed;
    }
}
