import java.util.LinkedList;
public class WritingResult extends AbsResult implements IChallenge {


    // day of November last update was made (1-30)

    //LinkedList<Double> words = new LinkedList<Double>();

    /**
     * constructor
     * @param words as words
     * @param day as days done
     */
    public WritingResult(double words, int day) {
        super(words, day);
    }

    /**
     * add a new chapter in the LinkedList
     * @param chapter double that is added to the list
     * @return WritingResult itself
     */
    public WritingResult nextChapter(double chapter) {
        this.words.add(chapter);
        return this;
    }

    /**
     * calculates average writing per day
     * @return double
     */
    public double averagePerDay() {
        double count = 0.0;
        for(double thisChapter: this.words) {
            count += thisChapter;
        }
        return count/day;
    }


    /**
     * calculates different from writing goal
     * @return double of that calculation
     */
    public double differenceFromGoal() {
        double count = 0;
        for(double thiswrite: this.words) {
            count += thiswrite;
        }

        return count/(30 - this.day + 1);
    }
}
