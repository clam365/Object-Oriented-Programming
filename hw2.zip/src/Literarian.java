public class Literarian {
    ChallengeResult newcr;
    String penName;

    public Literarian(String penName, ChallengeResult newcr) {
        this.newcr = newcr;
        this.penName = penName;
    }

    public boolean betterBookworm(Literarian literarian) {
        return (literarian.newcr.howClose() > this.newcr.howClose());
    }

    public boolean wittierWordsmith (Literarian literarian) {
        return (literarian.newcr.readresult.averagePerDay() < this.newcr.readresult.averagePerDay());
    }

    public boolean successfulScholar (Literarian literarian) {
        return literarian.wittierWordsmith(literarian) || literarian.betterBookworm(literarian);
    }



}
