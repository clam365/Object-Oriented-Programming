public class WritingResult implements IChallenge {

    // # of words written (including partial)
    double words;

    // day of November last update was made (1-30)
    int day;

    public WritingResult(double words, int day) {
        this.words = words;
        this.day = day;
    }

    public double averagePerDay() {
        return ( (this.words)/ this.day);
    }

    public double differenceFromGoal() {
        return ((50000 - this.words) / (30 - this.day + 1));
    }
}
