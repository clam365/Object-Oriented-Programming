import static org.junit.Assert.*;
import org.junit.Test;

public class Examples {
    public Examples() {}

    BooksRead booksRead1 = new BooksRead(12.0);
    BooksRead booksRead2 = new BooksRead(6.0);
    ReadingResult readingResult = new ReadingResult(2, booksRead1, booksRead2);
    WritingResult writingResult = new WritingResult(25000.5, 15);
    ChallengeResult challengeResult = new ChallengeResult(readingResult,
            writingResult);

    Literarian literarian1 = new Literarian(challengeResult);
    Literarian literarian2 = new Literarian(challengeResult);

    BooksRead booksRead3 = new BooksRead(15.0);
    BooksRead booksRead4 = new BooksRead(10.0);
    ReadingResult readingResult3 = new ReadingResult(3, booksRead3, booksRead4);
    WritingResult writingResult3 = new WritingResult(30000, 20);
    ChallengeResult challengeResult3 = new ChallengeResult(readingResult3, writingResult3);
    Literarian literarian3 = new Literarian(challengeResult3);

    @Test
    public void testReadingAveragePerDay() {
        assertEquals(readingResult.averagePerDay(), 0.580, 0.01);
    }

    @Test
    public void testWritingAveragePerDay() {
        assertEquals(writingResult.averagePerDay(), 1666.7, 0.01);
    }

    @Test
    public void testReadingDifferenceFromGoal() {
        assertEquals(readingResult.differenceFromGoal(), 1.419, 0.01);
    }

    @Test
    public void testWritingDifferenceFromGoal() {
        assertEquals(writingResult.differenceFromGoal(), 1562.468, 0.001);
    }

    @Test
    public void testHowClose() {
        assertEquals(challengeResult.howClose(), 15756.017, 0.01);
    }

    @Test
    //testing the same things/ false
    public void testBetterBookworm() {
        assertFalse(literarian1.betterBookworm(literarian2));
    }

    @Test
    //Testing if it's better
    public void testTrueBetterBookworm() {
        assertTrue(literarian1.betterBookworm(literarian3));
    }

    @Test
    //false case (it will always be false with literarian 1 and 2 so pointless)
    public void testFalseWittierWordSmith() {
        assertFalse(literarian1.wittierWordsmith(literarian3));
    }

    @Test
    //true case
    public void testTrueWitterWordsmith() {
        assertTrue(literarian3.wittierWordsmith(literarian1));
    }

    @Test
    // false case
    public void testFalseSuccessfulScholar() {
        assertFalse(literarian3.successfulScholar(literarian1));
    }

    @Test
    // true case
    public void testTrueSuccessfulScholar() {
        assertFalse(literarian1.successfulScholar(literarian3));
    }


}

