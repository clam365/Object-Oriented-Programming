public class BooksRead {

    // books read (includes partial)
    double booksread;

    public BooksRead(double booksread) {
        this.booksread = booksread;
    }
}
