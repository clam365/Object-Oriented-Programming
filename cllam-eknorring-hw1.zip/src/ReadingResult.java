import java.awt.print.Book;

public class ReadingResult implements IChallenge {

    // Average books per-day goal set in advanced
    int average;

    //books
    BooksRead fiction;
    BooksRead nonfiction;

    public ReadingResult(int average, BooksRead fiction, BooksRead nonfiction) {
        this.average = average;
        this.fiction = fiction;
        this.nonfiction = nonfiction;
    }

    public double averagePerDay() {
        return ((fiction.booksread + nonfiction.booksread) / 31 );
    }

    public double differenceFromGoal() {
        return (average - this.averagePerDay());
    }





}
